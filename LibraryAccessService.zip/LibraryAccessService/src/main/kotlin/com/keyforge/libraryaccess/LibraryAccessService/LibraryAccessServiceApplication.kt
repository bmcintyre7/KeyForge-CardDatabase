package com.keyforge.libraryaccess.LibraryAccessService

import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication
import org.springframework.context.annotation.Bean

@EnableAutoConfiguration
@SpringBootApplication
class LibraryAccessServiceApplication {
    @Bean
    fun controller() = CardsController()
}

fun main(args: Array<String>) {
    runApplication<LibraryAccessServiceApplication>(*args)
}
