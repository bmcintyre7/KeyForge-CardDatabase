package com.keyforge.libraryaccess.LibraryAccessService

import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
class CardsController {
    @RequestMapping("/cards")
    fun getCards() = 10
}